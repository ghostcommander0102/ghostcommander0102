<style lang="scss">
@import "../scss/selectorder.scss";
</style>
<template>
  <div class="container">
    <div class="Summary-panel">
      
      <div class="wrapper" >
        <div class="container">
          <div class="top"></div>
          <div class="bottom">
            <div class="left">
              <div class="details">
                <h1>{{ pizza_list[detail.selected_pizza].title }}</h1>
                <p>{{ pizza_list[detail.selected_pizza].price }}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="topping-list">
        <div v-for="topping in topping_list"
              :key="topping.id"
              @change="clickTopping(topping.id)" >
              <p v-if="topping.selected">{{topping.title}} / {{topping.price}}</p>
        </div>
      </div>
      
    </div>
    <p class="total-price">
        ${{total_price}} / ${{total_price * 85 / 100}}
      </p>
  </div>
</template>
<script>
export default {
  data() {
    return {
      total_price: 0,
    };
  },
  props: ["detail.selected_pizza", "pizza_list", "topping_list", "detail"],
  setup() {},
  mounted() {
    for(var i=0;i<this.topping_list.length;i++){
      if(this.topping_list[i].selected)
        this.total_price += this.topping_list[i].value;
    }
    this.total_price += this.pizza_list[this.detail.selected_pizza].value;
  },
  methods: {
    
  },
  created() {

  }
};
</script>