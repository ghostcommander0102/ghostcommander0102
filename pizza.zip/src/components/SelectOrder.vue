<style lang="scss">
@import "../scss/selectorder.scss";
</style>
<template>
  <div class="container">
    <div class="row">
      <div class="process">
        <div class="process-row nav nav-tabs">
          <div class="process-step">
            <button
              type="button"
              class="btn btn-info btn-circle"
              data-toggle="tab"
              href="#menu1"
            >
              <i class="fa fa-info fa-3x"></i>
            </button>
            <p>
              <small>Choose<br />Size</small>
            </p>
          </div>
          <div class="process-step">
            <button
              type="button"
              class="btn btn-default btn-circle"
              data-toggle="tab"
              href="#menu2"
            >
              <i class="fa fa-file-text-o fa-3x"></i>
            </button>
            <p>
              <small>Choose<br />Toppings</small>
            </p>
          </div>
          <div class="process-step">
            <button
              type="button"
              class="btn btn-default btn-circle"
              data-toggle="tab"
              href="#menu3"
            >
              <i class="fa fa-check fa-3x"></i>
            </button>
            <p>
              <small>Customer<br />detail</small>
            </p>
          </div>
        </div>
      </div>
      <div class="tab-content">
        <div id="menu1" class="tab-pane fade active in">
          <div class="pizza-panel">
            <div
              v-for="pizza in pizza_list"
              class="wrapper auto"
              :key="pizza.id"
              :class="pizza.id == detail.selected_pizza ? 'selected' : ''"
              @click.stop="clickPizza(pizza.id)"
            >
              <div class="container">
                <div class="top"></div>
                <div class="bottom">
                  <div class="left">
                    <div class="details">
                      <h1>{{ pizza.title }}</h1>
                      <p>{{ pizza.price }}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <ul class="list-unstyled list-inline pull-right">
            <li>
              <button type="button" class="btn btn-info next-step">
                Next <i class="fa fa-chevron-right"></i>
              </button>
            </li>
          </ul>
        </div>
        <div id="menu2" class="tab-pane fade">
          <div class="topping-panel">
            <label
              class="checkbox"
              v-for="topping in topping_list"
              :key="topping.id"
              @change="clickTopping(topping.id)"
            >
              <input type="checkbox" v-model="topping.selected" v-bind:id="topping.id"/>
              <i class="fa fa-2x icon-checkbox"></i>
              {{ topping.title }} / {{ topping.price }}
            </label>
          </div>
          <ul class="list-unstyled list-inline pull-right">
            <li>
              <button type="button" class="btn btn-default prev-step">
                <i class="fa fa-chevron-left"></i> Back
              </button>
            </li>
            <li>
              <button type="button" class="btn btn-info next-step">
                Next <i class="fa fa-chevron-right"></i>
              </button>
            </li>
          </ul>
        </div>
        <div id="menu3" class="tab-pane fade">
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" class="form-control" id="name" v-model="detail.name"/>
              </div>
              <div class="form-group">
                <label for="add">Address:</label>
                <input type="text" class="form-control" id="add" v-model="detail.address"/>
              </div>
              <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" class="form-control" id="phone" v-model="detail.phone"/>
              </div>
            </div>
          </div>
          <ul class="list-unstyled list-inline pull-right">
            <li>
              <button type="button" class="btn btn-default prev-step">
                <i class="fa fa-chevron-left"></i> Back
              </button>
            </li>
            <li>
              <button type="button" class="btn btn-success" @click.stop="clickDone()">
                <i class="fa fa-check"></i> Done!
              </button>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
    props: ['detail.selected_pizza','pizza_list','topping_list','detail'],
  data() {
    return {
      
    };
  },
  
  setup() {},
  mounted() {
    let recaptchaScript = document.createElement("script");
    recaptchaScript.setAttribute("src", "/src/js/selectorder.js");
    document.head.appendChild(recaptchaScript);
  },
  methods: {
    clickPizza(id) {
      this.detail.selected_pizza = id;
    },
    clickTopping(id) {
        var count = 0;
        for(var i=0;i<this.topping_list.length;i++){
            if(this.topping_list[i].selected == true){
                count++;
            }
        }
        if(count > 6){
            alert("you can not pick more");
            this.topping_list[id].selected = false;
            return;
        }
        if(id == 7 && this.topping_list[9].selected == true){
            alert('You have already picked Mozzarella');
            this.topping_list[id].selected = false;
            return;
        }
        if(id == 9 && this.topping_list[7].selected == true){
            alert('You have already picked Bacon');
            this.topping_list[id].selected = false;
            return;
        }
    },
    clickDone(){
        this.$router.setRoute( '/Summary' );
    }
  },
};
</script>