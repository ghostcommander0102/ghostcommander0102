<template>
  <div class="app-wrap">
    <!-- topbar with logo and menu -->
    <!-- <Topbar
      :header="header"
      :options="options"
      :tickerStatus="tickerStatus"
      :tickerTime="tickerTime"
      :priceData="priceData"
      :historyData="historyData"
      :alarmsData="alarmsData"
      :newsEntries="newsEntries"
    >
    </Topbar> -->


    <!-- main app pages wrapper -->
    <div class="app-main">
      <keep-alive>
        <component
          :is="mainComp"
          :key="mainComp"
          :pizza_list="pizza_list"
          :topping_list="topping_list"
          :detail="detail"
          class="fx fx-fade-in"
        >
        </component>
      </keep-alive>
    </div>
  </div>
</template>


<script>
import SelectOrder from "./SelectOrder.vue";
import Summary from "./Summary.vue";
// component
export default {
  // component list
  components: {
    SelectOrder,
    Summary,
  },

  // component data
  data() {
    return {
      pizza_list: [
        {
          id: 0,
          title: "small",
          price: "$5",
		  value: 5
        },
        {
          id: 1,
          title: "medium",
          price: "$10",
		  value: 10
        },
        {
          id: 2,
          title: "large",
          price: "$15",
		  value: 15
        },
        {
          id: 3,
          title: "extra large",
          price: "$20",
		  value: 20
        },
      ],
      topping_list: [
        {
          id: 0,
          title: "Mushrooms",
          price: "$1",
		  value: 1,
          selected: false,
        },
        {
          id: 1,
          title: "Olives",
          price: "$1",
		  value: 1,
          selected: false,
        },
        {
          id: 2,
          title: "Tomato",
          price: "free",
		  value: 0,
          selected: false,
        },
        {
          id: 3,
          title: "Tona",
          price: "$3",
		  value: 3,
          selected: false,
        },
        {
          id: 4,
          title: "Pineapple",
          price: "$3",
		  value: 3,
          selected: false,
        },
        {
          id: 5,
          title: "Seafood",
          price: "$5",
		  value: 5,
          selected: false,
        },
        {
          id: 6,
          title: "Pepperoni",
          price: "$2",
		  value: 2,
          selected: false,
        },
        {
          id: 7,
          title: "Bacon",
          price: "$1",
		  value: 1,
          selected: false,
        },
        {
          id: 8,
          title: "Onion",
          price: "free",
		  value: 0,
          selected: false,
        },
        {
          id: 9,
          title: "Mozzarella",
          price: "$3",
		  value: 3,
          selected: false,
        },
      ],
      detail: {
		  selected_pizza: 0,
        c_name: "",
        c_address: "",
        c_phone: "",
      },

      mainComp: "",
    };
  },

  // custom methods
  methods: {
    // update app options and pass it on to other handlers
    // setup options class handlers and load saved options

    // setup app routes
    setupRoutes() {
      // page routes
      this.$router.on("/", () => {
        this.showPage("SelectOrder", "Select Order");
      });
      this.$router.on("/Summary", () => {
        this.showPage("Summary", "Summary");
      });
    },

    // set a url hash route
    setRoute(route) {
      this.$router.setRoute(route);
    },

    // setup global event bus handlers
    // change visible page component
    showPage(component, title) {
      this.mainComp = component;
    },

    // show modal window
  },

  // on component created
  created() {
    this.setupRoutes();
  },

  // on component mounted
  mounted() {
    this.$router.trigger(window.location.hash || "/");
  },

  // on component destroyed
  destroyed() {},
};
</script>
