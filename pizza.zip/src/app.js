/**
 * Main app entry file.
 */
window.DEBUG = false;

// app dependencies
import App from './components/App.vue';
import Vue from 'vue';
import Router from './modules/router';
// setup common helper classes
const _router = new Router();
// create custom global vue properties
Object.defineProperties( Vue.prototype, {
  $router: { get() { return _router; } },
});

// single tooltip instance for entire app
Vue.directive( 'tooltip', {
  bind: el => { _tooltip.select( el ); },
  unbind: el => { _tooltip.unselect( el ); },
});

// global filters used to format currency and price change values

// init and/or render
window.addEventListener( 'load', e => {
  if ( window.top !== window ) return;
  document.body.setAttribute( 'tabindex', '0' );
  new Vue( { el: '#app', render: h => h( App ) } );
});
